
let balance = 0;

document.getElementById('coin').addEventListener('click', (event) => {
    balance += 1;
    updateBalanceDisplay();
});

function updateBalanceDisplay() {
    document.getElementById('balance').innerText = `Coins: ${balance}`;
}

function navigate(screen) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(`${screen}-screen`).classList.add('active');
}
